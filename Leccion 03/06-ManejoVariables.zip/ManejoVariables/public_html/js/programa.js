
document.write("Programa para declaración de variables:<br/>");

//Declaración de Variables
var x = 5;
var y = 6;
var z = x + y;

/*
 * JavaScript es sencible a mayúsculas. 
 * Lo siguiente causa error var z = X + y;
*/

document.write("Valor de x: " + x + ", y: " + y + " y z:" + z);
//Imprimimos un salto de linea en html
document.write("<br/>");

//Declaracion en una sola linea
var a = -5, b = 4, c = a + b;

document.write("Valor de a: " + a + ", b: " + b + " y c:" + c);


function miFuncion2(nombre){
    alert("Hola " + nombre + " desde funcion2");
}

function mostrarNombre( parametro ){
    var nombre = parametro.value;
    alert("Hola " + nombre + " desde mostrarNombre");
}
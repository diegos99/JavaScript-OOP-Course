function determinaClasificacionPorEdades(entrada) {
    var resultado = null;
    var edad = entrada.value;
    console.log("Valor edad:" + edad);

    /* 
     * Determinamos el rango de edades
     * A   - Apta para todo público
     * B   - Para mayores de 12 años
     * B15 - Para mayores de 15 años
     * C   - Para 18 años en adelante
     * D   - De 21 años en adelante
     */

    if (edad > 0 && edad < 12) {
        resultado = "AA y A";
    }
    else if (edad >= 12 && edad < 15) {
        resultado = "B, AA y A";
    }
    else if (edad >= 15 && edad < 18) {
        resultado = "B15, AA y A";
    }
    else if (edad >= 18 && edad < 21) {
        resultado = "C, B15, AA y A";
    }
    else if (edad >= 21 && edad <= 122) {
        resultado = "Puedes ver cualquier tipo de películas :)";
    }
    else if (edad > 122) {
        resultado = "No creo que exista alguna persona con tantos años!";
    }
    else {
        resultado = "Valor erroneo";
    }
    document.getElementById("resultado").innerHTML = resultado;
}